package dao;

import java.sql.ResultSet;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;
import modelo.Producto;

public class ProductoImpl extends Conexion {

    public List listar() throws Exception {

        List<Producto> listado = null;
        String sql = "";
        Producto prov;
        try {
            listado = new ArrayList();
            sql = "SELECT * FROM PRODUCTO";
            Statement st = this.conectar().createStatement();
            ResultSet rs = st.executeQuery(sql);

            while (rs.next()) {
                prov = new Producto();
                prov.setIdproducto(rs.getInt("IDPRO"));
                prov.setNombre(rs.getString("NOMPRO"));
                prov.setPrecio(rs.getDouble("PREPRO"));
                prov.setTamaño(rs.getString("TAMPRO"));
                prov.setStock(rs.getInt("STOCKPRO"));
                prov.setEstado(rs.getString("ESTPRO"));
                prov.setDetalle(rs.getString("DETPRO"));
                prov.setCategoria(rs.getString("CATPRO"));

                listado.add(prov);
            }
            rs.close();
            st.close();
        } catch (Exception e) {
            System.out.println("Error en LISTAR()/ProductoImpl" + e.getMessage());
        }
        return listado;
    }
}
