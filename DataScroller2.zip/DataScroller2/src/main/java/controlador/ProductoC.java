package controlador;

import dao.ProductoImpl;
import java.io.Serializable;
import java.util.List;
import javax.enterprise.context.SessionScoped;
import javax.faces.application.FacesMessage;
import javax.faces.context.FacesContext;
import javax.inject.Named;
import modelo.Producto;

@Named(value = "ProductosC")
@SessionScoped
public class ProductoC implements Serializable {

    private List<Producto> listadoProd;
    private Producto prod;
    private ProductoImpl dao;

    private Integer numero1;

    public ProductoC() {
        prod = new Producto();
        dao = new ProductoImpl();

    }

    public void listar() {
        try {
            listadoProd = dao.listar();
        } catch (Exception e) {
            System.out.println("Error en listarC" + e.getMessage());
        }
    }

    public void cancelar() {
        numero1 = null;
    }

    public void culmanado() {
        FacesContext.getCurrentInstance().addMessage(null, new FacesMessage(FacesMessage.SEVERITY_INFO, "OK", "Carga completa"));
    }

    public void añadir() {
        FacesContext.getCurrentInstance().addMessage(null, new FacesMessage(FacesMessage.SEVERITY_INFO, "OK", "Producto Añadido"));
    }

    public List<Producto> getListadoProd() {
        return listadoProd;
    }

    public void setListadoProd(List<Producto> listadoProd) {
        this.listadoProd = listadoProd;
    }

    public Producto getProd() {
        return prod;
    }

    public void setProd(Producto prod) {
        this.prod = prod;
    }

    public ProductoImpl getDao() {
        return dao;
    }

    public void setDao(ProductoImpl dao) {
        this.dao = dao;
    }

    public Integer getNumero1() {
        return numero1;
    }

    public void setNumero1(Integer numero1) {
        this.numero1 = numero1;
    }

}
